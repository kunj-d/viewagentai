<style>

    /*Setting Pag Card Effects*/



</style>



  <!-- Container Start -->

  <div class="container-wrapper container-open"><title><?php echo $this->config->item('productName') ?> | Settings</title>

        <!-- Main Container Start -->

        <div class="container-fluid container-padding" style=" min-height: calc(93vh);">

            <div class="row">

                <div class="col-12">

                    <div class="title-line mb-3">

                        Settings

                    </div>

                </div>

            </div>

            <div class="row">
                
                
        <?php if ($this->session->userdata('logged_in')['id'] == $this->session->userdata('logged_in')['owner_id']) { ?>

            <div class="col-lg-3 col-md-4">

                <a href="<?= base_url('workspace') ?>" class="setting-box">

                    <div class="text-center">

                        <i class="fa-solid fa-briefcase setting-icon"></i>

                        <h5 class="mt-4">Manage Workspace</h5>

                    </div>

                     <span class="bg m-0 p-0"></span>

                </a>

            </div>
            
        <?php //if ($this->session->userdata('logged_in')['id'] == $this->session->userdata('logged_in')['owner_id'] || $this->session->userdata('logged_in')['user_role'] != 'team') { ?>


            <!--<div class="col-lg-3 col-md-4">

                 <a href="<?= base_url('client-management')?>" class="setting-box">

                    <div class="text-center">

                        <i class="fa-solid fa-users-gear setting-icon"></i>

                        <h5 class="mt-4">Manage Client's</h5>

                    </div>

                                   

                     <span class="bg m-0 p-0"></span>

                  </a>

            </div>
            
            <div class="col-lg-3 col-md-4">

                 <a href="<?= base_url('team-management') ?>" class="setting-box">

                    <div class="text-center">

                        <span class="icon-team-management setting-icon"></span>

                        <h5 class="mt-4">Manage Team's</h5>

                    </div>

                     <span class="bg m-0 p-0"></span>

                </a>

            </div>-->
            
         <?php } ?> 
         
         
          <!-- <?php if (($this->session->userdata('logged_in')['id'] == $this->session->userdata('logged_in')['owner_id']) || in_array('whitelabel', $team_privileges)) {?>
            <div class="col-lg-3 col-md-4">

                <a href="<?= base_url('whitelabel-setting') ?>" class="setting-box">

                <div class="text-center">

                    <span class="fa-solid fa-certificate setting-icon"></span>

                    <h5 class="mt-4">Whitelabel</h5>

                </div>

                    <span class="bg m-0 p-0"></span>

                </a>

            </div>
            <?php } ?>-->

            

            <div class="col-lg-3 col-md-4">

                 <a href="javascript:void(0);" class="setting-box">
                 <!-- <a href="<?= base_url('subscription') ?>" class="setting-box"> -->

                    <div class="text-center">

                        <span class="icon-subscription setting-icon"></span>

                        <h5 class="mt-4">Subscription</h5>

                    </div>

                     <span class="bg m-0 p-0"></span>

                 </a>

            </div>

        <?php if (($this->session->userdata('logged_in')['id'] == $this->session->userdata('logged_in')['owner_id']) || in_array('integration', $team_privileges)) {?>
            <div class="col-lg-3 col-md-4">

                 <a href="<?= base_url('integration'); ?>" class="setting-box">

                    <div class="text-center">

                        <span class="icon-integration setting-icon"></span>

                        <h5 class="mt-4">Integration</h5>

                    </div>

                     <span class="bg m-0 p-0"></span>

                 </a>

            </div>
        <?php } ?>

            <div class="col-lg-3 col-md-4 ">
                 <a href="javascript:void(0);" class="setting-box">
                 <!-- <a href="<?= base_url('training') ?>" class="setting-box"> -->
                 <!-- <a href="https://ai-tube-star.dotcompal.co/videos" class="setting-box" target="_blank"> -->

                    <div class="text-center">

                        <span class="icon-tutorial setting-icon"></span>

                        <h5 class="mt-4">Tutorial</h5>

                    </div>

                     <span class="bg m-0 p-0"></span>

                </a>

            </div>

             <div class="col-lg-3 col-md-4">

                 <a href="javascript:void(0);" class="setting-box">
                 <!-- <a href="<?= base_url('bonuses/vip-bonuses') ?>" class="setting-box"> -->

                    <div class="text-center">

                        <span class="icon-bonus setting-icon"></span>

                        <h5 class="mt-4">Bonuses</h5>

                    </div>

                    <span class="bg m-0 p-0"></span>

                </a>

            </div>

            <div class="col-lg-3 col-md-4">
                <a href="javascript:void(0);" class="setting-box">
                <!-- <a href="<?= base_url('faqs') ?>" class="setting-box"> -->

                    <div class="text-center">

                        <i class="icon-support setting-icon"></i>

                        <h5 class="mt-4">Support</h5>

                    </div> 

                     <span class="bg m-0 p-0"></span>

                  </a>

            </div>

        </div>

    </div>

<script>

$(function() {  

$('.setting-box')

.on('mouseenter', function(e) {

        var parentOffset = $(this).offset(),

          relX = e.pageX - parentOffset.left,

          relY = e.pageY - parentOffset.top;

        $(this).find('.bg').css({top:relY, left:relX})

})

.on('mouseout', function(e) {

        var parentOffset = $(this).offset(),

          relX = e.pageX - parentOffset.left,

          relY = e.pageY - parentOffset.top;

        $(this).find('.bg').css({top:relY, left:relX})

});

});



</script>





    